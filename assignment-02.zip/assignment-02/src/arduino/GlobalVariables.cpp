#include "GlobalVariables.h"
volatile bool error = false;
volatile bool welcome = false;
volatile bool moving =false;
volatile bool ready = false;
volatile bool washing = false;
volatile bool leaving = false;
volatile bool closing = false;
volatile bool sleeping = true;
volatile bool isNear = false;
volatile bool gateState = false;
volatile int carCounter = 0;